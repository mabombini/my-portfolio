
package gcesports_at3_gui;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class DB_Write {
    
private String dbURL;
private String usrID;
private String usrPWD;
private Connection conn;
private Statement stmt;
private ResultSet rs;
private String errorMessage;

public DB_Write (String sql)
{

    try
    {
        BufferedReader bufferedReader = new BufferedReader(new FileReader("app.config"));
        
        //reads first line from the external file
        String line = bufferedReader.readLine();
        
        int lineCounter = 1;
        
        while (line != null)
        {
            switch(lineCounter)
            {
                case 1:
                    dbURL = line.substring(6, line.length());
                  break;
                case 2:
                    usrID = line.substring(6, line.length());
                  break;
                case 3:
                    usrPWD = line.substring(7, line.length());
                  break;
                default:
                  break;
            }
                    
            line = bufferedReader.readLine();
            lineCounter++;
           
        }
        
    bufferedReader.close();
    }
    catch (IOException ioe)
    {
        errorMessage = ioe.getMessage() + "\n";
    }
    catch (Exception e)
    {
        errorMessage = e.getMessage() + "\n";
    }
    
    try
{
// make connection and execute SQL query
conn = DriverManager.getConnection(dbURL, usrID,
usrPWD);
stmt = conn.createStatement();
// executeUpdate(sql) used for INSERT INTO, UPDATE and DELETE FROM statements
stmt.executeUpdate(sql);
// close the connection
conn.close();
}
// catch SQL Exceptions
catch (SQLException e)
{
errorMessage = e.getMessage();
System.out.println("SQL exception: " + errorMessage);
}
// catch any other possible exception
catch (Exception e)
{
errorMessage = e.getMessage();
System.out.println("Other exception: " + errorMessage);
}
} // end constructor method
}

    

