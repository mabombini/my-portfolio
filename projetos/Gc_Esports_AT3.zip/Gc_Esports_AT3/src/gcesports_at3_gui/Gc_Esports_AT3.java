
package gcesports_at3_gui;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import static java.lang.Integer.parseInt;

import java.util.ArrayList;
import java.util.Collections;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import java.util.Arrays;

/*Author: Marina Bombini
Date: 11-05-2025
Version: 1.0
*/

public class Gc_Esports_AT3 extends javax.swing.JFrame 
{
    //private data fields - resize tables
    private DefaultTableModel compResultsTableModel;
    private DefaultTableModel leaderBoardEventTableModel;
    
    //objects to process database connection and sql
    private DB_Read dbRead;
    private DB_Write dbWrite;
    
    //currently chosen event at combobox
    private String chosenEvent;
    //currently chosen team at combobox
    private String chosenTeam;
    
    //string variable to create sql statements
    private String sql;
 
   
    /* Method
   Method name: Constructor method Gc_Esports_AT3() 
   Purpose: creates JFrame and sets up all data from JTables and Comboboxes
   Inputs: void
   Output: void
    */
    public Gc_Esports_AT3() 
    {        
        //creates array with titles to use as parameter in method setColumnIdentifiers (competition results)
        String [] columnNames_CompResults = new String[] {"Game","Team 1","Pt",
                                                           "Team 2", "Pt"};
        compResultsTableModel = new DefaultTableModel();
        compResultsTableModel.setColumnIdentifiers(columnNames_CompResults);
        compResultsTableModel.setColumnIdentifiers(columnNames_CompResults);
        
        //creates array with titles to use as parameter in method setColumnIdentifiers (leaderboard)
        String [] columnNames_EventsLeaderBoard = new String[] {"Team","Total Points"};
        leaderBoardEventTableModel = new DefaultTableModel();
        leaderBoardEventTableModel.setColumnIdentifiers(columnNames_EventsLeaderBoard);
        
        
        //initialise prIvate fields
        chosenEvent = "All events";
        chosenTeam = "All teams";
        sql = "";
        
        
        //initialise GUI components
        initComponents();
        
        
        resizeTableColumnsCompetitionResults();
        
        resizeTableColumnsEventLeaderboard();
        
        displayCompResults();
        
        displayEventListing();
        
        displayTeamListing();
        
        displayGameListing();
        
        displayEventsLeaderboard();
        
        //set current date and location
        LocalDate dateObj = LocalDate.now();
        DateTimeFormatter formater = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        String todaysDate = dateObj.format(formater);
        newEventDate_JTextField.setText(todaysDate);
        newEventLocation_JTextField.setText("Tafe Coomera");    
    }
    


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        header_JPanel = new javax.swing.JPanel();
        header_JLabel = new javax.swing.JLabel();
        body_JPanel = new javax.swing.JPanel();
        body_JTabbedPane = new javax.swing.JTabbedPane();
        eventCompResults__JPpanel = new javax.swing.JPanel();
        event_JLabel = new javax.swing.JLabel();
        team_JLabel = new javax.swing.JLabel();
        event_JComboBox = new javax.swing.JComboBox<>();
        team_JComboBox = new javax.swing.JComboBox<>();
        compResults_JLabel = new javax.swing.JLabel();
        eventLeaderboard_JLabel = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        leaderboard_JTable = new javax.swing.JTable();
        records_JTextField = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        compResults_JTable = new javax.swing.JTable();
        exportCompetition_JButton = new javax.swing.JButton();
        exportLeaderboard_JButton = new javax.swing.JButton();
        addNewCompResult_JPpanel = new javax.swing.JPanel();
        Event2_JLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        event2_JComboBox = new javax.swing.JComboBox<>();
        game_JComboBox = new javax.swing.JComboBox<>();
        team1_JLabel = new javax.swing.JLabel();
        team2_JLabel = new javax.swing.JLabel();
        team1_JComboBox = new javax.swing.JComboBox<>();
        team2_JComboBox = new javax.swing.JComboBox<>();
        team1Points_JLabel = new javax.swing.JLabel();
        team2Points_JLabel = new javax.swing.JLabel();
        team1Points_JTextField = new javax.swing.JTextField();
        team2Points_JTextField = new javax.swing.JTextField();
        addNewComp_JButton = new javax.swing.JButton();
        addNewTeam_JPpanel = new javax.swing.JPanel();
        newTeamName_JLabel = new javax.swing.JLabel();
        newTeamContact_JLabel = new javax.swing.JLabel();
        newTeamPhone_JLabel = new javax.swing.JLabel();
        newTeamEmail_JLabel = new javax.swing.JLabel();
        newTeamName_JTextField = new javax.swing.JTextField();
        newTeamContact_JTextField = new javax.swing.JTextField();
        newTeamPhone_JTextField = new javax.swing.JTextField();
        newTeamEmail_JTextField = new javax.swing.JTextField();
        addNewTeam_JButton = new javax.swing.JButton();
        uodateExistingTeam_JPpanel = new javax.swing.JPanel();
        teamName_JLabel = new javax.swing.JLabel();
        contactName_JLabel = new javax.swing.JLabel();
        emailAddress_JLabel = new javax.swing.JLabel();
        phoneNumber_JLabel = new javax.swing.JLabel();
        teamNameUpdate_JComboBox = new javax.swing.JComboBox<>();
        contactNameUpdate_JTextField = new javax.swing.JTextField();
        phoneNumberUpdate_JTextField = new javax.swing.JTextField();
        emailAddressUpdate_JTextField = new javax.swing.JTextField();
        updateExistingTeam_JButton = new javax.swing.JButton();
        addNewEvent_JPpanel = new javax.swing.JPanel();
        newEventName_JLabel = new javax.swing.JLabel();
        newEventDate_JLabel = new javax.swing.JLabel();
        newEventLocation_JLabel = new javax.swing.JLabel();
        newEventName_JTextField = new javax.swing.JTextField();
        newEventDate_JTextField = new javax.swing.JTextField();
        newEventLocation_JTextField = new javax.swing.JTextField();
        addNewEvent_JButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        header_JLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image_package/goldcoast_esports_v2.jpg"))); // NOI18N

        javax.swing.GroupLayout header_JPanelLayout = new javax.swing.GroupLayout(header_JPanel);
        header_JPanel.setLayout(header_JPanelLayout);
        header_JPanelLayout.setHorizontalGroup(
            header_JPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(header_JLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        header_JPanelLayout.setVerticalGroup(
            header_JPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(header_JLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        eventCompResults__JPpanel.setBackground(new java.awt.Color(255, 255, 255));

        event_JLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        event_JLabel.setText("Event:");

        team_JLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        team_JLabel.setText("Team:");

        event_JComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All events" }));
        event_JComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                event_JComboBoxItemStateChanged(evt);
            }
        });
        event_JComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                event_JComboBoxActionPerformed(evt);
            }
        });

        team_JComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All teams" }));
        team_JComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                team_JComboBoxItemStateChanged(evt);
            }
        });

        compResults_JLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        compResults_JLabel.setText("Competition results for all events (all teams) :");

        eventLeaderboard_JLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        eventLeaderboard_JLabel.setText("Event leaderboard for all events:");

        leaderboard_JTable.setModel(leaderBoardEventTableModel);
        jScrollPane1.setViewportView(leaderboard_JTable);

        compResults_JTable.setModel(compResultsTableModel);
        jScrollPane2.setViewportView(compResults_JTable);

        exportCompetition_JButton.setText("Export competition result as CSV files");
        exportCompetition_JButton.setActionCommand("");
        exportCompetition_JButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exportCompetition_JButtonActionPerformed(evt);
            }
        });

        exportLeaderboard_JButton.setText("Export leaderboard as CSV file");
        exportLeaderboard_JButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exportLeaderboard_JButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout eventCompResults__JPpanelLayout = new javax.swing.GroupLayout(eventCompResults__JPpanel);
        eventCompResults__JPpanel.setLayout(eventCompResults__JPpanelLayout);
        eventCompResults__JPpanelLayout.setHorizontalGroup(
            eventCompResults__JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(eventCompResults__JPpanelLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(eventCompResults__JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(eventCompResults__JPpanelLayout.createSequentialGroup()
                        .addComponent(team_JLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(team_JComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 454, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(eventCompResults__JPpanelLayout.createSequentialGroup()
                        .addComponent(event_JLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(event_JComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 454, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(eventCompResults__JPpanelLayout.createSequentialGroup()
                        .addGap(25, 25, 25)
                        .addGroup(eventCompResults__JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(exportLeaderboard_JButton)
                            .addGroup(eventCompResults__JPpanelLayout.createSequentialGroup()
                                .addGroup(eventCompResults__JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(eventCompResults__JPpanelLayout.createSequentialGroup()
                                        .addGroup(eventCompResults__JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addGroup(eventCompResults__JPpanelLayout.createSequentialGroup()
                                                .addComponent(records_JTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(exportCompetition_JButton))
                                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 425, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGap(18, 18, 18))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, eventCompResults__JPpanelLayout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(compResults_JLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 357, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                .addGroup(eventCompResults__JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 296, Short.MAX_VALUE)
                                    .addComponent(eventLeaderboard_JLabel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        eventCompResults__JPpanelLayout.setVerticalGroup(
            eventCompResults__JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(eventCompResults__JPpanelLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(eventCompResults__JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(event_JLabel)
                    .addComponent(event_JComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(eventCompResults__JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(team_JLabel)
                    .addComponent(team_JComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(eventCompResults__JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(compResults_JLabel)
                    .addComponent(eventLeaderboard_JLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(eventCompResults__JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(eventCompResults__JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(records_JTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(exportCompetition_JButton)
                    .addComponent(exportLeaderboard_JButton))
                .addContainerGap(298, Short.MAX_VALUE))
        );

        body_JTabbedPane.addTab("Event competition results", eventCompResults__JPpanel);

        addNewCompResult_JPpanel.setBackground(new java.awt.Color(255, 255, 255));

        Event2_JLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        Event2_JLabel.setText("Event:");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("Game:");

        team1_JLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        team1_JLabel.setText("Team 1:");

        team2_JLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        team2_JLabel.setText("Team 2:");

        team1Points_JLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        team1Points_JLabel.setText("Team 1 Points:");

        team2Points_JLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        team2Points_JLabel.setText("Team 2 Points:");

        addNewComp_JButton.setText("ADD NEW COMPETITION RESULT");
        addNewComp_JButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addNewComp_JButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout addNewCompResult_JPpanelLayout = new javax.swing.GroupLayout(addNewCompResult_JPpanel);
        addNewCompResult_JPpanel.setLayout(addNewCompResult_JPpanelLayout);
        addNewCompResult_JPpanelLayout.setHorizontalGroup(
            addNewCompResult_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addNewCompResult_JPpanelLayout.createSequentialGroup()
                .addGroup(addNewCompResult_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(addNewCompResult_JPpanelLayout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(addNewCompResult_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(team1_JLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(addNewCompResult_JPpanelLayout.createSequentialGroup()
                                .addComponent(team2_JLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(team2_JComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 365, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(addNewCompResult_JPpanelLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(addNewCompResult_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Event2_JLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(addNewCompResult_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(event2_JComboBox, 0, 364, Short.MAX_VALUE)
                            .addComponent(game_JComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(team1_JComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(18, 18, 18)
                .addGroup(addNewCompResult_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(addNewCompResult_JPpanelLayout.createSequentialGroup()
                        .addComponent(team1Points_JLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(team1Points_JTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(234, 234, 234))
                    .addGroup(addNewCompResult_JPpanelLayout.createSequentialGroup()
                        .addComponent(team2Points_JLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(team2Points_JTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, addNewCompResult_JPpanelLayout.createSequentialGroup()
                .addComponent(addNewComp_JButton)
                .addGap(247, 247, 247))
        );
        addNewCompResult_JPpanelLayout.setVerticalGroup(
            addNewCompResult_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addNewCompResult_JPpanelLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(addNewCompResult_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Event2_JLabel)
                    .addComponent(event2_JComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(addNewCompResult_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(game_JComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(addNewCompResult_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(team1_JLabel)
                    .addComponent(team1_JComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(team1Points_JLabel)
                    .addComponent(team1Points_JTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(addNewCompResult_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(team2_JLabel)
                    .addComponent(team2_JComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(team2Points_JLabel)
                    .addComponent(team2Points_JTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(88, 88, 88)
                .addComponent(addNewComp_JButton)
                .addContainerGap(366, Short.MAX_VALUE))
        );

        body_JTabbedPane.addTab("Add new competition result", addNewCompResult_JPpanel);

        addNewTeam_JPpanel.setBackground(new java.awt.Color(255, 255, 255));

        newTeamName_JLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        newTeamName_JLabel.setText("New Team Name:");

        newTeamContact_JLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        newTeamContact_JLabel.setText("Contact Name:");

        newTeamPhone_JLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        newTeamPhone_JLabel.setText("Phone Number:");

        newTeamEmail_JLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        newTeamEmail_JLabel.setText("Email Address:");

        newTeamPhone_JTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                newTeamPhone_JTextFieldActionPerformed(evt);
            }
        });

        addNewTeam_JButton.setText("ADD NEW TEAM");
        addNewTeam_JButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addNewTeam_JButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout addNewTeam_JPpanelLayout = new javax.swing.GroupLayout(addNewTeam_JPpanel);
        addNewTeam_JPpanel.setLayout(addNewTeam_JPpanelLayout);
        addNewTeam_JPpanelLayout.setHorizontalGroup(
            addNewTeam_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addNewTeam_JPpanelLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(addNewTeam_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(newTeamEmail_JLabel)
                    .addComponent(newTeamPhone_JLabel)
                    .addComponent(newTeamContact_JLabel)
                    .addComponent(newTeamName_JLabel))
                .addGap(41, 41, 41)
                .addGroup(addNewTeam_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(newTeamName_JTextField)
                    .addComponent(newTeamContact_JTextField)
                    .addComponent(newTeamPhone_JTextField)
                    .addComponent(newTeamEmail_JTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 306, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, addNewTeam_JPpanelLayout.createSequentialGroup()
                .addContainerGap(395, Short.MAX_VALUE)
                .addComponent(addNewTeam_JButton)
                .addGap(284, 284, 284))
        );
        addNewTeam_JPpanelLayout.setVerticalGroup(
            addNewTeam_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addNewTeam_JPpanelLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(addNewTeam_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(newTeamName_JLabel)
                    .addComponent(newTeamName_JTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(addNewTeam_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(newTeamContact_JLabel)
                    .addComponent(newTeamContact_JTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(addNewTeam_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(newTeamPhone_JLabel)
                    .addComponent(newTeamPhone_JTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(addNewTeam_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(newTeamEmail_JLabel)
                    .addComponent(newTeamEmail_JTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(48, 48, 48)
                .addComponent(addNewTeam_JButton)
                .addContainerGap(379, Short.MAX_VALUE))
        );

        body_JTabbedPane.addTab("Add new team ", addNewTeam_JPpanel);

        uodateExistingTeam_JPpanel.setBackground(new java.awt.Color(255, 255, 255));

        teamName_JLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        teamName_JLabel.setText("Team Name:");

        contactName_JLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        contactName_JLabel.setText("Contact Name:");

        emailAddress_JLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        emailAddress_JLabel.setText("Email Address:");

        phoneNumber_JLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        phoneNumber_JLabel.setText("Phone Number:");

        teamNameUpdate_JComboBox.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                teamNameUpdate_JComboBoxItemStateChanged(evt);
            }
        });

        updateExistingTeam_JButton.setText("UPDATE EXISTING TEAM");
        updateExistingTeam_JButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateExistingTeam_JButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout uodateExistingTeam_JPpanelLayout = new javax.swing.GroupLayout(uodateExistingTeam_JPpanel);
        uodateExistingTeam_JPpanel.setLayout(uodateExistingTeam_JPpanelLayout);
        uodateExistingTeam_JPpanelLayout.setHorizontalGroup(
            uodateExistingTeam_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(uodateExistingTeam_JPpanelLayout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(uodateExistingTeam_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(updateExistingTeam_JButton)
                    .addGroup(uodateExistingTeam_JPpanelLayout.createSequentialGroup()
                        .addGroup(uodateExistingTeam_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(phoneNumber_JLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(emailAddress_JLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(contactName_JLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(teamName_JLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(uodateExistingTeam_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(teamNameUpdate_JComboBox, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(contactNameUpdate_JTextField)
                            .addComponent(phoneNumberUpdate_JTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 294, Short.MAX_VALUE)
                            .addComponent(emailAddressUpdate_JTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 294, Short.MAX_VALUE))))
                .addContainerGap(380, Short.MAX_VALUE))
        );
        uodateExistingTeam_JPpanelLayout.setVerticalGroup(
            uodateExistingTeam_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(uodateExistingTeam_JPpanelLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(uodateExistingTeam_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(teamName_JLabel)
                    .addComponent(teamNameUpdate_JComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(uodateExistingTeam_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(contactName_JLabel)
                    .addComponent(contactNameUpdate_JTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(uodateExistingTeam_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(phoneNumber_JLabel)
                    .addComponent(phoneNumberUpdate_JTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(uodateExistingTeam_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(emailAddress_JLabel)
                    .addComponent(emailAddressUpdate_JTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(46, 46, 46)
                .addComponent(updateExistingTeam_JButton)
                .addContainerGap(381, Short.MAX_VALUE))
        );

        body_JTabbedPane.addTab("Update existing team", uodateExistingTeam_JPpanel);

        addNewEvent_JPpanel.setBackground(new java.awt.Color(255, 255, 255));

        newEventName_JLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        newEventName_JLabel.setText("New Event Name:");

        newEventDate_JLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        newEventDate_JLabel.setText("Date:");

        newEventLocation_JLabel.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        newEventLocation_JLabel.setText("Location:");

        addNewEvent_JButton.setText("ADD NEW EVENT");
        addNewEvent_JButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addNewEvent_JButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout addNewEvent_JPpanelLayout = new javax.swing.GroupLayout(addNewEvent_JPpanel);
        addNewEvent_JPpanel.setLayout(addNewEvent_JPpanelLayout);
        addNewEvent_JPpanelLayout.setHorizontalGroup(
            addNewEvent_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addNewEvent_JPpanelLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(addNewEvent_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(newEventLocation_JLabel)
                    .addComponent(newEventName_JLabel)
                    .addComponent(newEventDate_JLabel))
                .addGap(18, 18, 18)
                .addGroup(addNewEvent_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(newEventName_JTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(newEventDate_JTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(newEventLocation_JTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(310, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, addNewEvent_JPpanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(addNewEvent_JButton)
                .addGap(296, 296, 296))
        );
        addNewEvent_JPpanelLayout.setVerticalGroup(
            addNewEvent_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(addNewEvent_JPpanelLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(addNewEvent_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(newEventName_JLabel)
                    .addComponent(newEventName_JTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(addNewEvent_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(newEventDate_JLabel)
                    .addComponent(newEventDate_JTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(addNewEvent_JPpanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(newEventLocation_JTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(newEventLocation_JLabel))
                .addGap(44, 44, 44)
                .addComponent(addNewEvent_JButton)
                .addContainerGap(432, Short.MAX_VALUE))
        );

        body_JTabbedPane.addTab("Add new event", addNewEvent_JPpanel);

        javax.swing.GroupLayout body_JPanelLayout = new javax.swing.GroupLayout(body_JPanel);
        body_JPanel.setLayout(body_JPanelLayout);
        body_JPanelLayout.setHorizontalGroup(
            body_JPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 799, Short.MAX_VALUE)
            .addGroup(body_JPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(body_JPanelLayout.createSequentialGroup()
                    .addComponent(body_JTabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 799, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        body_JPanelLayout.setVerticalGroup(
            body_JPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(body_JPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, body_JPanelLayout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(body_JTabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(header_JPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(body_JPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(header_JPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(body_JPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 478, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static String formatDateToString(String inputDateString)
    {
        // create date string version
        String formattedDateStr = "";
        String day = inputDateString.substring(8, 10);
        String year = inputDateString.substring(0, 4);
        String month = "Jan";
        String monthNbr = inputDateString.substring(5, 7);
        switch (monthNbr)
        {
            case "02": 
                month = "Feb";
                break;
            case "03":
                month = "Mar";
                break;
            case "04":
                month = "Apr";
                break;
            case "05":
                month = "May";
                break;

            case "06":
                month = "Jun";
                break;
            case "07":
                month = "Jul";
                break;
            case "08":
                month = "Aug";
                break;
            case "09":
                month = "Sep";
                break;
            case "10":
                month = "Oct";
                break;
            case "11":
                month = "Nov";
                break;
            case "12":
                month = "Dec";
                break;
            default:
                break;
        }
        
        formattedDateStr = day + "-" + month + "-" + year;
        
        return formattedDateStr;
    }

         
    /* 
   Method name: resizeTableColumnsCompetitionResults() 
   Purpose: Resize the columns of the JTable to display the competition results
   Inputs: void
   Output: void
    */
    
    private void resizeTableColumnsCompetitionResults()
    {
    //array of sizes to each column
    float[] columnWidthPercentage = {0.2f, 0.2f, 0.01f, 0.2f, 0.01f};
    int tableWidth = compResults_JTable.getWidth();
    
    TableColumn column;

    TableColumnModel tableColumnModel = compResults_JTable.getColumnModel();
    
    int cantCols = tableColumnModel.getColumnCount();
    

    for (int i = 0; i < cantCols; i++)
    {
      column = tableColumnModel.getColumn(i);  
      float pWidth = Math.round(columnWidthPercentage[i] * tableWidth);
      column.setPreferredWidth ((int)pWidth);
    }
    } //End method resizeTableColumnsCompetitionResults
    
    
    /* 
    Method name: resizeTableColumnsEventLeaderboard() 
    Purpose: Resize the columns of the JTable to display the event leaderboard
    Inputs: void
    Output: void
    */
    private void resizeTableColumnsEventLeaderboard()
    {
        
    //array of sizes to each column
    float[] columnWidthPercentage = {0.3f, 0.3f, 0.05f, 0.3f, 0.05f};
    
    int tableWidth = leaderboard_JTable.getWidth();

    TableColumn column;

    TableColumnModel tableColumnModel = leaderboard_JTable.getColumnModel();
    
    int cantCols = tableColumnModel.getColumnCount();
    
    for (int i = 0; i < cantCols; i++)
    {
      column = tableColumnModel.getColumn(i);  
      float pWidth = Math.round(columnWidthPercentage[i] * tableWidth);
      column.setPreferredWidth ((int)pWidth);
    }
    } //End method resizeTableColumnsEventLeaderboard
    
    
    /* 
    Method name: displayCompResults()
    Purpose: Reads information from database and displays in the competition results JTable 
    Inputs: void
    Output: void
    */     
    private void displayCompResults()
    {
        //SQL queries to retrieve information from database
        String sql = "SELECT gameName, team1, team1points, team2, team2points "
                      + "FROM goldcoast_esports.competition";
        
        //String variable to handle the dynamically changing label on top of Jtable Competition results
        String compResultsLabelText = "Competition results";
        
        
        //checks if the option all events is not selected 
        if (!chosenEvent.equals("All events"))
        {
            sql += " WHERE eventName = '" + chosenEvent + "'";           
            compResultsLabelText += " for " + chosenEvent;
        }//end if
        
        //checks if the option all teams is not selected 
        if (!chosenTeam.equals("All teams"))
        {           
           sql += " AND (team1 = '" + chosenTeam + "' OR team2 = '" + chosenTeam+"');";            
            compResultsLabelText += " and " + chosenTeam;  
        }//end if
        
        //creates new object to the class DB_Read to retrieve data from the database
        DB_Read dbRead = new DB_Read(sql, "competition");
        
        //check if the result set is not empty
        if (dbRead.getRecordCount() > 0)
        {   
            //checks if Jtable is not empty
            if (compResultsTableModel.getRowCount() > 0)
            {
                //goes through and deletes the rows in the JTable 
                for (int i= compResultsTableModel.getRowCount() - 1; i>-1; i--)
                {
                    compResultsTableModel.removeRow(i);
                }//end for loop    
            }//end if to check if JTable is not empty
        
        
            //check if 2d array has the result set 
            if (dbRead.getObjDataSet().length > 0)
            {
                //adds rows to the JTable with new result set 
                for (int row = 0; row < dbRead.getObjDataSet().length; row++)
                {
                    compResultsTableModel.addRow(dbRead.getObjDataSet()[row]);
                }//end for loop
                
                    compResultsTableModel.fireTableDataChanged();
            }//end if to check 2d array ObjDataSet()

               compResultsTableModel.fireTableDataChanged(); 
        }//end if checking if result set is empty
        else
        {
            //if the result set is empty it means that there are no entries registered for the selected event
            //rows are deleted and jtable shows no results 
            if (compResultsTableModel.getRowCount() > 0)
            {
                for (int i= compResultsTableModel.getRowCount() - 1; i>-1; i--)
                {
                    compResultsTableModel.removeRow(i);
                }    
            }
            compResultsTableModel.fireTableDataChanged();
        }
           
           //uses the method getRecordCount to check how many rows of data were generated
           records_JTextField.setText(dbRead.getRecordCount() + " record(s) found");
           
           compResults_JLabel.setText(compResultsLabelText);
        
    } //end method displayCompResults()
    
   /* 
    Method name: displayEventListing()
    Purpose: Populates all the comboboxes that list the events 
    Inputs: void
    Output: void
    */     
    private void displayEventListing()
    {
        //SQL queries to retrieve information from database
        String sql = "SELECT name, date, location FROM goldcoast_esports.event";
        //creates new object to the class DB_Read to retrieve data from the database
        DB_Read dbRead = new DB_Read(sql, "event");
        
        
        
        
        if (dbRead.getErrorMessage().isEmpty())
        {
            //for loop goes through each row of events and adds to event comboboxes 
            for(int row=0; row < dbRead.getObjDataSet().length; row++)
            {
                event_JComboBox.addItem(dbRead.getObjDataSet()[row][0].toString() + " (" + formatDateToString(dbRead.getObjDataSet()[row][1].toString()) + " " + dbRead.getObjDataSet()[row][2].toString() +")");
                event2_JComboBox.addItem(dbRead.getObjDataSet()[row][0].toString());
            }//end for loop event combobox
        }
        else
        {
            System.out.println(dbRead.getErrorMessage());
        }
    }//end method display event listing
    
    /* 
    Method name: displayTeamListing()
    Purpose: Populates the comboboxes that list the events 
    Inputs: void
    Output: void
    */
    private void displayTeamListing()
    {
        //SQL queries to retrieve information from database
        String sql = "SELECT name FROM goldcoast_esports.team";
        //creates new object to the class DB_Read to retrieve data from the database
        DB_Read dbRead = new DB_Read(sql, "team_names");
        
        //for loop goes through each row of events and adds to teams comboboxes 
        for(int row=0; row < dbRead.getObjDataSet().length; row++)
        {        
            team_JComboBox.addItem(dbRead.getObjDataSet()[row][0].toString());
            team1_JComboBox.addItem(dbRead.getObjDataSet()[row][0].toString());
            team2_JComboBox.addItem(dbRead.getObjDataSet()[row][0].toString());
            teamNameUpdate_JComboBox.addItem(dbRead.getObjDataSet()[row][0].toString());
        }
    }//end displayTeamListing()
    
        /* 
    Method name: displayTeamListing()
    Purpose: Populates the comboboxe that lists the games 
    Inputs: void
    Output: void
    */
    private void displayGameListing()
    {
        String sql = "SELECT name FROM goldcoast_esports.game";
        
        DB_Read dbRead = new DB_Read(sql, "game");
        
        //for loop goes through each row of games and adds to games combobox
        for(int row=0; row < dbRead.getObjDataSet().length; row++)
        {        
            game_JComboBox.addItem(dbRead.getObjDataSet()[row][0].toString());
        }
    }
    
    /* 
    Method name: displayEventsLeaderboard()
    Purpose: Reads information from database and displays in the competition results JTable 
    Inputs: void
    Output: void
    */
    
    private void displayEventsLeaderboard() 
    {
    
        //sql query in case "All Events" is selected
        sql = "SELECT name, SUM(totalPoints) AS points "
        + "FROM (SELECT team.name, SUM(team1Points) AS totalPoints "
        + "FROM competition INNER JOIN team ON team.name = competition.team1 "
        + "GROUP BY team.name UNION SELECT team.name, SUM(team2Points) AS totalPoints "
        + "FROM competition INNER JOIN team ON team.name = competition.team2 "
        + "GROUP BY team.name ORDER BY totalPoints DESC) AS derivedTable "
        + "GROUP BY name ORDER BY points DESC;";
        
        //String variable to handle the dynamically changing label on top of Jtable Leaderboard
        String leaderBoardLabelText = "Event leaderboard";
        
        //Set label to "Event leaderboard" only - "All events" selected
        eventLeaderboard_JLabel.setText(leaderBoardLabelText);
    
    //checks if a event was selected
    if (!chosenEvent.equals("All events"))
    {   
        //sql query in case a event is selected (where eventName = event selected name)
        sql = "SELECT name, SUM(totalPoints) AS points "
        + "FROM (SELECT team.name, SUM(team1Points) AS totalPoints "
        + "FROM competition INNER JOIN team ON team.name = competition.team1 "
        + "WHERE eventName = '" + chosenEvent + "' "
        +"GROUP BY team.name UNION SELECT team.name, SUM(team2Points) AS totalPoints "
        +"FROM competition INNER JOIN team ON team.name = competition.team2 "
        + "WHERE eventName = '" + chosenEvent + "' "
        + "GROUP BY team.name ORDER BY totalPoints DESC) AS derivedTable "
        + "GROUP BY name ORDER BY points DESC;";
            
        //String variable to handle the dynamically changing label on top of Jtable Leaderboard results
        leaderBoardLabelText += " for " + chosenEvent;
        
        //Set label showing the selected event
        eventLeaderboard_JLabel.setText(leaderBoardLabelText);
    }//end if check if a event was selected
        
    //creates new object to the class DB_Read to retrieve data from the database    
    DB_Read dbRead = new DB_Read (sql, "leaderboard");
    
    
    
    //checks if the result set is not empty
    if (dbRead.getRecordCount() > 0)
    {   
        //checks if the JTable is not empty
        if (leaderBoardEventTableModel.getRowCount() > 0)
            {
                //goes through and deletes the rows in the JTable for leaderboard
                for (int i= leaderBoardEventTableModel.getRowCount() - 1; i>-1; i--)
                {
                    leaderBoardEventTableModel.removeRow(i);
                }    
            }//end if 
        
            //check if 2d array has the result set 
            if (dbRead.getObjDataSet().length > 0)
            {
                //adds rows to the JTable with new result set 
                for (int row = 0; row < dbRead.getObjDataSet().length; row++)
                    {
                        leaderBoardEventTableModel.addRow(dbRead.getObjDataSet()[row]);
                    }//end for loop
                    
                leaderBoardEventTableModel.fireTableDataChanged();
            }//end if
       
             leaderBoardEventTableModel.fireTableDataChanged(); 
    } //end if checks rsult set
    else
    {
            //if the result set is empty it means that there are no entries registered for that event
            //rows are deleted and jtable shows no results        
            if (leaderBoardEventTableModel.getRowCount() > 0)
            {
                for (int i= leaderBoardEventTableModel.getRowCount() - 1; i>-1; i--)
                {
                    leaderBoardEventTableModel.removeRow(i);
                }    
            }
            leaderBoardEventTableModel.fireTableDataChanged();   
    }//end else
    } // end method displayEventsLeaderboard()
    
    
    
    

    
    private void newTeamPhone_JTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_newTeamPhone_JTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_newTeamPhone_JTextFieldActionPerformed
        /* 
    Method name: updateExistingTeam_JButtonActionPerformed(java.awt.event.ActionEvent evt)
    Purpose: Reads information from database and displays in the competition results JTable 
    Inputs: void
    Output: void
    */
    private void updateExistingTeam_JButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateExistingTeam_JButtonActionPerformed
    
        //get selected items on comboboxes and assign to variables
        String name = teamNameUpdate_JComboBox.getSelectedItem().toString();
        String contactUpdate = contactNameUpdate_JTextField.getText();
        String phoneUpdate = phoneNumberUpdate_JTextField.getText();
        String emailUpdate = emailAddressUpdate_JTextField.getText();
        
        //string to retrieve possible error messages
        String errorMessage = "";
        
        if (contactNameUpdate_JTextField.getText().isEmpty())
        {
        errorMessage += "- contact person's name is required \n";
        }
        if (phoneNumberUpdate_JTextField.getText().isEmpty())
        {
        errorMessage += "- contact's phone number is required \n";
        }
        if (emailAddressUpdate_JTextField.getText().isEmpty())
        {
        errorMessage += "- contact's email address is required \n";
        }
        
        //check if errorMessage is empty. If not, it means that no errors were encountered
        if (errorMessage.isEmpty())
        {
         //confirms with user before writing in the database
         int reply = JOptionPane.showConfirmDialog(
         null,
         "You are about to save a new competiton result for: " + name + "\n Do you wish to continue?",
         "NEW COMPETITION RESULT",
         JOptionPane.YES_NO_OPTION);
             
            if (reply == JOptionPane.YES_OPTION)
            {
                //updates database data with variables
                String sql = "UPDATE team "
                     + "SET contact = '" + contactUpdate + "', "
                     + "phone = '" + phoneUpdate + "', "
                     + "email = '" + emailUpdate + "' "
                     + "WHERE name = '" + name +"';";

                //creates new object to the class DB_Write and updates data on the database
                DB_Write dbWrite = new DB_Write(sql);
            }
        }
        else //if errorMessage is not empty, it means that one or more errors were encountered
        {
          //display errors encountered
          JOptionPane.showMessageDialog(null, "Errors encoutered: \n" + errorMessage, 
                    "ERRORS DETECTED!", JOptionPane.ERROR_MESSAGE);     
        }
        
    }//GEN-LAST:event_updateExistingTeam_JButtonActionPerformed

    private void event_JComboBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_event_JComboBoxItemStateChanged
        
        String eventString = event_JComboBox.getSelectedItem().toString();
        
        chosenEvent = "All events";
        
        if (!eventString.equals("All events"))
        {
        //assign the selected event on the combobox to the variable
        chosenEvent = eventString.substring(0, (eventString.indexOf("(")-1));
        }
                
        //updates the JTables to show the data related to the selected event
        displayCompResults();
        displayEventsLeaderboard();
        
        

    }//GEN-LAST:event_event_JComboBoxItemStateChanged

    private void team_JComboBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_team_JComboBoxItemStateChanged
        // TODO add your handling code here:
        //assign the selected event on the combobox to the variable
        chosenTeam = team_JComboBox.getSelectedItem().toString();
        
        //updates the JTables to show the data related to the selected event
        displayCompResults();
        
    }//GEN-LAST:event_team_JComboBoxItemStateChanged

    private void teamNameUpdate_JComboBoxItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_teamNameUpdate_JComboBoxItemStateChanged
        
       //SQL query to retrieve information from the database
       String sql = "SELECT name, contact, phone, email FROM goldcoast_esports.team";
       
       //creates new object to the class DB_Read to retrieve data from the database
       DB_Read dbRead = new DB_Read(sql, "team");
       
       
       contactNameUpdate_JTextField.setText(dbRead.getObjDataSet()[0][1].toString());
       phoneNumberUpdate_JTextField.setText(dbRead.getObjDataSet()[0][2].toString());
       emailAddressUpdate_JTextField.setText(dbRead.getObjDataSet()[0][3].toString());
      
       
       //goes through the records in the result set generated by the sql execution
       for (int i=0; i < dbRead.getRecordCount(); i++)
       {
           //checks each line to see what record matches the selected team
           if (teamNameUpdate_JComboBox.getSelectedItem().toString().equals(dbRead.getObjDataSet()[i][0].toString()))
           {
               //sets the text on the text fields with the information of the selected team
               contactNameUpdate_JTextField.setText(dbRead.getObjDataSet()[i][1].toString());
               phoneNumberUpdate_JTextField.setText(dbRead.getObjDataSet()[i][2].toString());
               emailAddressUpdate_JTextField.setText(dbRead.getObjDataSet()[i][3].toString());
           }//end if
       }//end for loop
     
       
       
    }//GEN-LAST:event_teamNameUpdate_JComboBoxItemStateChanged

    private void exportCompetition_JButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exportCompetition_JButtonActionPerformed
    if (compResultsTableModel.getRowCount() > 0)
    {
    
    //tries to run the code block that writes on external file
    try
    {
    //writes on external file - false means it is in overwrite mode
    FileOutputStream outputStream = new
    FileOutputStream("Competition Results - "+chosenTeam+" "+chosenEvent+".csv", false);
    OutputStreamWriter outputStreamWriter = new
    OutputStreamWriter(outputStream, "UTF-8");
    BufferedWriter bufferedWriter = new
    BufferedWriter(outputStreamWriter);
    
   
       
    //retrieve data from JTable and writes on CSV format on external file 
    for (int i=0; i < compResultsTableModel.getRowCount(); i++)
    {       
    bufferedWriter.write(compResultsTableModel.getValueAt(i,0).toString() + "," 
                            + compResultsTableModel.getValueAt(i,1).toString() + ","
                            + compResultsTableModel.getValueAt(i,2).toString() + ","
                            + compResultsTableModel.getValueAt(i,3).toString() + ","
                            + compResultsTableModel.getValueAt(i,4).toString());
    bufferedWriter.newLine();
    }
    //close the bufferedWriter object
    bufferedWriter.close();
    
   
    //handles the exceptions if something goes wrong with the external file
    }
    catch (IOException e)
    {
    System.out.println("ERROR: Problem with writing data to external file!");
    }
    
    //message confirming the csv file was created
    JOptionPane.showMessageDialog(null, "CSV Data successfully written to file: Competition Results - "+chosenTeam+" "+chosenEvent+".csv","CSV Data Exported!", JOptionPane.INFORMATION_MESSAGE);
    
    } else
    {
    //error message if the event has no competition data
    JOptionPane.showMessageDialog(null,"Sorry, there is no competition data to save \n" 
                                       + "Select another event which contains competition results", 
                                         "No competition data to save", JOptionPane.ERROR_MESSAGE);
    }
    }//GEN-LAST:event_exportCompetition_JButtonActionPerformed

    private void exportLeaderboard_JButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exportLeaderboard_JButtonActionPerformed
    
    if (leaderBoardEventTableModel.getRowCount() > 0)
    {
         
    try
    {
    //writes on external file - false means it is in overwrite mode
    FileOutputStream outputStream = new
    FileOutputStream("Leaderboard Results - "+chosenEvent+".csv", false);
    OutputStreamWriter outputStreamWriter = new
    OutputStreamWriter(outputStream, "UTF-8");
    BufferedWriter bufferedWriter = new
    BufferedWriter(outputStreamWriter);
    
    
    
       
    //retrieve data from JTable and writes on CSV format on external file  
    for (int i=0; i < leaderBoardEventTableModel.getRowCount(); i++)
    {       
    bufferedWriter.write(leaderBoardEventTableModel.getValueAt(i,0).toString() + "," 
                            + leaderBoardEventTableModel.getValueAt(i,1).toString());


    bufferedWriter.newLine();
    }
    //close the bufferedWriter object
    bufferedWriter.close();
    }
    catch (IOException e)
    {
    System.out.println("ERROR: Problem with writing data to external file!");
    }
    
   JOptionPane.showMessageDialog(null, "CSV Data successfully written to file: Leaderboard Results - "+chosenEvent+".csv","CSV Data Exported!", JOptionPane.INFORMATION_MESSAGE);
    } else
    {
    JOptionPane.showMessageDialog(null,"Sorry, there is no competition data to save \n" 
                                       + "Select another event which contains competition results", 
                                         "No competition data to save", JOptionPane.ERROR_MESSAGE);
    }

                                                            

    }//GEN-LAST:event_exportLeaderboard_JButtonActionPerformed

    private void addNewComp_JButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addNewComp_JButtonActionPerformed
        // TODO add your handling code here:
        
        String errorMessage = "";
        String event = event2_JComboBox.getSelectedItem().toString();
        String game = game_JComboBox.getSelectedItem().toString();
        String team1 = team1_JComboBox.getSelectedItem().toString();
        String team2 = team2_JComboBox.getSelectedItem().toString();
        int points1 = parseInt(team1Points_JTextField.getText());
        int points2 = parseInt(team2Points_JTextField.getText());
        
        
        //check user inputs and add error to the errorMessage variable
        if (team1 == team2)
        {
            errorMessage += "- team 1 and team 2 must not have the same names \n";
        }
        if (points1 > 2 || points1 < 0)
        {
            errorMessage += "- team 1 points must be 0, 1 or 2 \n";
        }
        if (points2 > 2 || points2 < 0)
        {
            errorMessage += "- team 2 points must be 0, 1 or 2 \n";
        }
        if(points1 + points2 != 2)
        {
            errorMessage += "- team 1 and team 2 points must add to 2 \n";
        }
        
        
        //checks if errorMessage is not empty and show errors 
        if (!errorMessage.isEmpty())
        {
        JOptionPane.showMessageDialog(null, "Errors encoutered: \n" + errorMessage, 
                    "ERRORS DETECTED!", JOptionPane.ERROR_MESSAGE);
        }
        else //inserts data in the database if error message is empty (inputs are valid)
        {
            
          int reply = JOptionPane.showConfirmDialog(
            null,
            "You are about to save a new competiton result for: " +team1_JComboBox.getSelectedItem().toString() +" and " +team2_JComboBox.getSelectedItem().toString() + "\n Do you wish to continue?",
            "NEW COMPETITION RESULT",
            JOptionPane.YES_NO_OPTION);
        
        //confirms with user before writing in the database
        if (reply == JOptionPane.YES_OPTION)
        {
        
            String sqlRead = "SELECT gameName, team1, team1points, team2, team2points "
                      + "FROM goldcoast_esports.competition";
        
            dbRead = new DB_Read(sqlRead, "competition");
         
            int compID = dbRead.getRecordCount() + 1;
        
            String sqlWrite = "INSERT INTO competition (competitionID, eventName,gameName, team1, team2, team1points, team2points) VALUES ("
                        + compID + ", "
                        + "'" + event + "', "
                        + "'" + game + "', "
                        + "'" + team1 + "', "
                        + "'" + team2 + "', "
                         + points1 + ", "
                         + points2 +")";
        
        
        DB_Write dbWrite = new DB_Write(sqlWrite);
        
        //updates the JTable to reflect changes 
        displayCompResults();
        }//end if yes option
      }//end else       
    }//GEN-LAST:event_addNewComp_JButtonActionPerformed

    private void addNewTeam_JButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addNewTeam_JButtonActionPerformed
        
    //assign inputs from text fields to variables
    String newName = newTeamName_JTextField.getText();
    String newContactName = newTeamContact_JTextField.getText();
    String newPhone = newTeamPhone_JTextField.getText();
    String newEmail = newTeamEmail_JTextField.getText();
        
    String errorMessage ="";
        
    //check user inputs and add error to the errorMessage variable  
    if (newTeamName_JTextField.getText().isEmpty())
    {
        errorMessage += "- unique team name is required \n";
    }
    if (newTeamContact_JTextField.getText().isEmpty())
    {
        errorMessage += "- contact person's name is required \n";
    }
    if (newTeamPhone_JTextField.getText().isEmpty())
    {
        errorMessage += "- contact's phone number is required \n";
    }
    if (newTeamEmail_JTextField.getText().isEmpty())
    {
        errorMessage += "- contact's email address is required \n";
    }
    
    //retrieve team names from database
    String sqlRead = "SELECT name, contact, phone, email FROM goldcoast_esports.team";
    
    DB_Read dbRead = new DB_Read(sqlRead, "team");
    
    //goes through the names and check if new name input matches any existing team name record
    for (int i = 0; i < dbRead.getRecordCount(); i++)
    {
        //if there is a team with the same name, error message appears
        if (dbRead.getObjDataSet()[i][0].equals(newName))
        {
            errorMessage += "- team name already exists in the database (must be unique)";
        }
    }
    
    //checks if errorMessage is empty 
    if (errorMessage.isEmpty())
    {
    String sql = "INSERT INTO team (name, contact, phone, email) VALUES ("
                     + "'" + newName + "', "
                        + "'" + newContactName + "', "
                        + "'" + newPhone + "', "
                        + "'" + newEmail + "')";
       
        
        int reply = JOptionPane.showConfirmDialog(
                    null,
                    "You are about to save a new team for: " + newName + "\n Do you wish to continue?",
                    "ADD NEW TEAM",
                    JOptionPane.YES_NO_OPTION);        
          
        //confirms with user before writing in the database
        if (reply == JOptionPane.YES_OPTION)
        {
        
            //insert inputs into the database
            DB_Write dbWrite = new DB_Write(sql);
        
            //updates team comboboxes to reflect changes
            team_JComboBox.addItem(newName);
            team1_JComboBox.addItem(newName);
            team2_JComboBox.addItem(newName);
            teamNameUpdate_JComboBox.addItem(newName);
        }//end if yes option
    } 
    else //errorMessage is not empty - show errors encountered
    {
     JOptionPane.showMessageDialog(null, "Errors encoutered: \n" + errorMessage, 
                    "ERRORS DETECTED!", JOptionPane.ERROR_MESSAGE);
    }
     
                    
    }//GEN-LAST:event_addNewTeam_JButtonActionPerformed

    private void addNewEvent_JButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addNewEvent_JButtonActionPerformed
    
    //data formatter to validate date input
    LocalDate dateObj = LocalDate.now();
    DateTimeFormatter formater = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    
    
    String newEventDate = "";
    String newEventName = newEventName_JTextField.getText();
    String newEventLocation = newEventLocation_JTextField.getText();
    
    String errorMessage ="";
    //try block to validate date format
    try
    {
        LocalDate date = LocalDate.parse(newEventDate_JTextField.getText(),formater);     
        System.out.print(date);
        newEventDate = date.toString();
    }
    catch (Exception e)
    {
        errorMessage += "- event date must be 10 chars - format yyyy-MM-dd \n";
    }
     
    
//check user inputs and add error to the errorMessage variable     
    if (newEventName_JTextField.getText().isEmpty())
    {
        errorMessage += "- event name is required \n";
    }
    if (newEventDate_JTextField.getText().isEmpty())
    {
        errorMessage += "- event date is required \n";
    }
    if (newEventLocation_JTextField.getText().isEmpty())
    {
        errorMessage += "- event location is required \n";
    }

    //checks if error message is empty - which means no errors were encountered 
    if (errorMessage.isEmpty())   
    {   
         int reply = JOptionPane.showConfirmDialog(
                    null,
                    "You are about to save a new event for: " + newEventName + "\n Do you wish to continue?",
                    "ADD NEW TEAM",
                    JOptionPane.YES_NO_OPTION);        
          
        //confirms with user before writing in the database
        if (reply == JOptionPane.YES_OPTION)
        {
            String sql = "INSERT INTO event (name, date, location) VALUES ("
                     + "'" + newEventName + "', "
                        + "'" + newEventDate + "', "
                        + "'" + newEventLocation + "')";
            
            //inserts data into database
            DB_Write dbWrite = new DB_Write(sql);
            
            //reflect changes in comboboxes
            event_JComboBox.addItem(newEventName);
            event2_JComboBox.addItem(newEventName);
        }
    }
    else
    {
    JOptionPane.showMessageDialog(null, "Errors encoutered: \n" + errorMessage, 
                "ERRORS DETECTED!", JOptionPane.ERROR_MESSAGE);   
    }

    }//GEN-LAST:event_addNewEvent_JButtonActionPerformed

    private void event_JComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_event_JComboBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_event_JComboBoxActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Gc_Esports_AT3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Gc_Esports_AT3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Gc_Esports_AT3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Gc_Esports_AT3.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Gc_Esports_AT3().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Event2_JLabel;
    private javax.swing.JPanel addNewCompResult_JPpanel;
    private javax.swing.JButton addNewComp_JButton;
    private javax.swing.JButton addNewEvent_JButton;
    private javax.swing.JPanel addNewEvent_JPpanel;
    private javax.swing.JButton addNewTeam_JButton;
    private javax.swing.JPanel addNewTeam_JPpanel;
    private javax.swing.JPanel body_JPanel;
    private javax.swing.JTabbedPane body_JTabbedPane;
    private javax.swing.JLabel compResults_JLabel;
    private javax.swing.JTable compResults_JTable;
    private javax.swing.JTextField contactNameUpdate_JTextField;
    private javax.swing.JLabel contactName_JLabel;
    private javax.swing.JTextField emailAddressUpdate_JTextField;
    private javax.swing.JLabel emailAddress_JLabel;
    private javax.swing.JComboBox<String> event2_JComboBox;
    private javax.swing.JPanel eventCompResults__JPpanel;
    private javax.swing.JLabel eventLeaderboard_JLabel;
    private javax.swing.JComboBox<String> event_JComboBox;
    private javax.swing.JLabel event_JLabel;
    private javax.swing.JButton exportCompetition_JButton;
    private javax.swing.JButton exportLeaderboard_JButton;
    private javax.swing.JComboBox<String> game_JComboBox;
    private javax.swing.JLabel header_JLabel;
    private javax.swing.JPanel header_JPanel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable leaderboard_JTable;
    private javax.swing.JLabel newEventDate_JLabel;
    private javax.swing.JTextField newEventDate_JTextField;
    private javax.swing.JLabel newEventLocation_JLabel;
    private javax.swing.JTextField newEventLocation_JTextField;
    private javax.swing.JLabel newEventName_JLabel;
    private javax.swing.JTextField newEventName_JTextField;
    private javax.swing.JLabel newTeamContact_JLabel;
    private javax.swing.JTextField newTeamContact_JTextField;
    private javax.swing.JLabel newTeamEmail_JLabel;
    private javax.swing.JTextField newTeamEmail_JTextField;
    private javax.swing.JLabel newTeamName_JLabel;
    private javax.swing.JTextField newTeamName_JTextField;
    private javax.swing.JLabel newTeamPhone_JLabel;
    private javax.swing.JTextField newTeamPhone_JTextField;
    private javax.swing.JTextField phoneNumberUpdate_JTextField;
    private javax.swing.JLabel phoneNumber_JLabel;
    private javax.swing.JTextField records_JTextField;
    private javax.swing.JLabel team1Points_JLabel;
    private javax.swing.JTextField team1Points_JTextField;
    private javax.swing.JComboBox<String> team1_JComboBox;
    private javax.swing.JLabel team1_JLabel;
    private javax.swing.JLabel team2Points_JLabel;
    private javax.swing.JTextField team2Points_JTextField;
    private javax.swing.JComboBox<String> team2_JComboBox;
    private javax.swing.JLabel team2_JLabel;
    private javax.swing.JComboBox<String> teamNameUpdate_JComboBox;
    private javax.swing.JLabel teamName_JLabel;
    private javax.swing.JComboBox<String> team_JComboBox;
    private javax.swing.JLabel team_JLabel;
    private javax.swing.JPanel uodateExistingTeam_JPpanel;
    private javax.swing.JButton updateExistingTeam_JButton;
    // End of variables declaration//GEN-END:variables
}
