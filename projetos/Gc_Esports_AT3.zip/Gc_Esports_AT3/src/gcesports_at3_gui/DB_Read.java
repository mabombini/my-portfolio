
package gcesports_at3_gui;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DB_Read 
{
    private String dbURL;
    private String usrID;
    private String usrPWD;
    
    private Connection conn;
    private Statement stmt;
    private ResultSet rs;
    private int recordCount;
    private String errorMessage;
    private Object [][] objDataSet;
    private String [] stringCSVData;
    private int maxCompID;
   
    public DB_Read (String sql, String qryType)
    {
        dbURL="";
        usrID="";
        usrPWD="";
        
        recordCount = 0;
        
        errorMessage = "";
        
        objDataSet = null;
        stringCSVData = null;
        
        maxCompID = 0;
        
    try
    {
        BufferedReader bufferedReader = new BufferedReader(new FileReader("app.config"));
        
        //reads first line from the external file
        String line = bufferedReader.readLine();
        
        int lineCounter = 1;
        
        while (line != null)
        {
            switch(lineCounter)
            {
                case 1:
                    dbURL = line.substring(6, line.length());
                  break;
                case 2:
                    usrID = line.substring(6, line.length());
                  break;
                case 3:
                    usrPWD = line.substring(7, line.length());
                  break;
                default:
                  break;
            }
                    
            line = bufferedReader.readLine();
            lineCounter++;
           
        }
        
    bufferedReader.close();
    }
    catch (IOException ioe)
    {
        errorMessage = ioe.getMessage() + "\n";
    }
    catch (Exception e)
    {
        errorMessage = e.getMessage() + "\n";
    }
    
    try
    {
        //create connection
            Connection conn = DriverManager.getConnection(dbURL, usrID, usrPWD);
            
            //create statement
            Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
            
            ResultSet rs = stmt.executeQuery(sql);
              
            //get record count
            
           if (rs != null)
           {
               rs.beforeFirst();
               rs.last();
               recordCount = rs.getRow();
           }
           
           if (recordCount > 0)
           {
               int counter = 0;
               
               objDataSet = new Object [recordCount][];
               stringCSVData = new String [recordCount];
               
               maxCompID = 0;
               
               
               
               rs.beforeFirst();
               
               while (rs.next())
               {
                   if (qryType.equals("competition"))
                   {
                       Object [] obj = new Object[5];
                       
                       obj[0] = rs.getString("gameName");
                       obj[1] = rs.getString("team1");
                       obj[2] = rs.getInt("team1Points");
                       obj[3] = rs.getString("team2");
                       obj[4] = rs.getInt("team2points");
                       
                       objDataSet[counter] = obj;
                       counter++;
                   }
                  
                   else if (qryType.equals("team"))
                   {
                        Object [] obj = new Object[4];
                       
                       obj[0] = rs.getString("name");
                       obj[1] = rs.getString("contact");
                       obj[2] = rs.getInt("phone");
                       obj[3] = rs.getString("email");
                                              
                       objDataSet[counter] = obj;
                       counter++;
                       
                   }
                   else if (qryType.equals("event"))
                   {
                      Object [] obj = new Object[3];
                      
                      obj[0] = rs.getString("name");
                      obj[1] = rs.getString("date");
                      obj[2] = rs.getString("location");
                      
                      objDataSet[counter] = obj;
                      
                      counter++;
                   }
                   else if (qryType.equals("team_names"))
                   {
                      
                        
                      Object [] obj = new Object[1];
                      
                      obj[0] = rs.getString("name");
                      
                      objDataSet[counter] = obj;
                      
                      counter++;
                       
                   }
                   else if (qryType.equals("leaderboard"))
                   {
                       Object [] obj = new Object[2];
                      
                      obj[0] = rs.getString("name");
                      obj[1] = rs.getString("points");
                      
                      objDataSet[counter] = obj;
                      
                      counter++;
                   }
                   
                    else if (qryType.equals("game"))
                   {
                      
                        
                      Object [] obj = new Object[1];
                      
                      obj[0] = rs.getString("name");
                      
                      objDataSet[counter] = obj;
                      
                      counter++;
                       
                   }
            
                   
                   
               }
           }
            
            
    }
    catch (SQLException sqIE)
    {
        errorMessage += sqIE.getMessage();
    }
    
    catch (Exception e)
    {
        errorMessage += e.getMessage();
    }
    
    
    }
    
    
    
public int getRecordCount()
{
    return recordCount;
}
  
public String getErrorMessage()
{
    return errorMessage;
}

public int getCompMaxID() 
{
     return maxCompID;       
}

public String [] getStringCSVData()
{
    return stringCSVData;
}

public Object[][] getObjDataSet()
{
    return objDataSet;
}
    
}


